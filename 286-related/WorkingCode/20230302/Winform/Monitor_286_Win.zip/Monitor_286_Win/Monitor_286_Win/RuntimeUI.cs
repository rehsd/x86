﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.IO.Ports;
using System.Configuration;
using System.Management;
using Monitor_286_Win.Properties;

namespace Monitor_286_Win
{
    public partial class RuntimeUI : Form
    {
        private const int MSG_START_TRANSFER = 0x1000;
        protected override void WndProc(ref Message message)
        {
            if (message.Msg == MSG_START_TRANSFER)
            {
                if (ReadyToTransfer)
                {
                    SendROMImage();
                }
            }
            base.WndProc(ref message);
        }
        public bool ReadyToTransfer = false;
        SerialPort myPort;
        SerialPort myPortUSB;
        const int CONNECTION_RATE = 115200;             //Serial for Due
        const int CONNECTION_RATE_USB = 268435456;      //USB for Due
        const int LOGMAX = 5000;
        const int BUFFER_SIZE = 50;
        byte[] serialBuffer = new byte[BUFFER_SIZE];
        bool gettingBIOS = false;
        FileStream fs;
        DateTime startTime;
        DateTime endTime;
        MainForm mainForm;

        void PopulateSerialPorts()
        {
            try
            {
                ManagementObjectCollection mbsList = null;
                ManagementObjectSearcher mbs = new ManagementObjectSearcher("Select DeviceID, Description From Win32_SerialPort");
                mbsList = mbs.Get();

                foreach (ManagementObject mo in mbsList)
                {
                    PortsCombo.Items.Add(mo["DeviceID"].ToString() + ": " + mo["Description"].ToString());
                    PortsComboUSB.Items.Add(mo["DeviceID"].ToString() + ": " + mo["Description"].ToString());
                }

                mbs = new ManagementObjectSearcher("SELECT * FROM Win32_PnPEntity WHERE Name LIKE '%(COM%' AND Name LIKE '%USB%'");
                mbsList = mbs.Get();

                foreach (ManagementObject mo in mbsList)
                {
                    PortsCombo.Items.Add(mo["Name"].ToString() + ": " + mo["Description"].ToString());
                    PortsComboUSB.Items.Add(mo["Name"].ToString() + ": " + mo["Description"].ToString());
                }
            }
            catch (Exception xcp)
            {
                MessageBox.Show(xcp.Message, "Ya'...., something failed...");
            }
        }

        public RuntimeUI()
        {
            InitializeComponent();
        }
        public RuntimeUI(MainForm parent)
        {
            this.mainForm = parent;
            InitializeComponent();
        }

        private void UpdateROMData()
        {
            FileInfo fi = new FileInfo(Settings.Default.ROMImage);
            ROMImageSizeLabel.Text = (fi.Length / 1024) + " KB";
            ROMImageLastModified.Text = fi.LastWriteTime.ToString();
        }
        private void RuntimeUI_Load(object sender, EventArgs e)
        {
            try
            {
                PopulateSerialPorts();
                if (Settings.Default.ROMImage.Trim().Length > 0)
                {
                    ROMimageLocationLabel.Text = Path.GetDirectoryName(Settings.Default.ROMImage);
                    ROMImageFileNameLabel.Text = Path.GetFileName(Settings.Default.ROMImage);
                    UpdateROMData();
                }
            }
            catch (Exception xcp)
            {
                MessageBox.Show(xcp.Message, "Ya'...., something failed...");
            }
        }

        private void ConnectButton_Click(object sender, EventArgs e)
        {
            try
            {
                if (ConnectButton.Text == "&Connect")
                {
                    string s = PortsCombo.SelectedItem.ToString();
                    s = s.Substring(s.IndexOf("COM"),5);
                    myPort = new SerialPort(s, CONNECTION_RATE);
                    myPort.ReadTimeout = 5000;
                    myPort.WriteTimeout = 5000;
                    myPort.WriteBufferSize = 256 * 1024;
                    //myPort.Parity = Parity.Even;
                    myPort.Open();
                    connectionStatusPictureBox.BackColor = Color.Green;
                    System.Threading.Thread.Sleep(1000);
                    myPort.DataReceived += new SerialDataReceivedEventHandler(MyPort_DataReceived);
                    myPort.DiscardInBuffer();
                    connectionSpeedLabel.Text = s + " @ " + myPort.BaudRate.ToString();
                    myPort.DiscardInBuffer();
                    ConnectButton.Text = "&Disconnect";
                    SendTextTextBox.Enabled = true;
                    SendButton.Enabled = true;
                }
                else
                {
                    if (myPort.IsOpen)
                    {
                        //To do Fix deadlock condition when UI thread is processing incoming bytes, but trying to close connection.
                        myPort.Close();
                    }
                    connectionStatusPictureBox.BackColor = Color.Red;
                    ConnectButton.Text = "&Connect";
                    connectionSpeedLabel.Text = "";
                    SendTextTextBox.Enabled = false;
                    SendButton.Enabled = false;
                }
            }
            catch (Exception xcp)
            {
                MessageBox.Show(xcp.Message, "Ya'...., something failed...");
            }
        }

        private void ConnectButtonUSB_Click(object sender, EventArgs e)
        {
            try
            {
                if (ConnectButtonUSB.Text == "&Connect")
                {
                    string s = PortsComboUSB.SelectedItem.ToString();
                    s = s.Substring(s.IndexOf("COM"), 5);
                    myPortUSB = new SerialPort(s, CONNECTION_RATE_USB);
                    myPortUSB.ReadTimeout = 5000;
                    myPortUSB.WriteTimeout = 5000;
                    myPortUSB.WriteBufferSize = 256 * 1024;
                    //myPortUSB.Parity = Parity.Even;
                    myPortUSB.Open();
                    connectionStatusPictureBoxUSB.BackColor = Color.Green;
                    System.Threading.Thread.Sleep(1000);
                    myPortUSB.DataReceived += new SerialDataReceivedEventHandler(MyPortUSB_DataReceived);
                    myPortUSB.DiscardInBuffer();
                    connectionSpeedLabelUSB.Text = s + " @ " + myPortUSB.BaudRate.ToString();
                    myPortUSB.DiscardInBuffer();
                    ConnectButtonUSB.Text = "&Disconnect";
                    TransferButton.Enabled = true;
                    ReadyToTransfer = true;
                }
                else
                {
                    if (myPortUSB.IsOpen)
                    {
                        //To do Fix deadlock condition when UI thread is processing incoming bytes, but trying to close connection.
                        myPortUSB.Close();
                    }
                    connectionStatusPictureBoxUSB.BackColor = Color.Red;
                    ConnectButtonUSB.Text = "&Connect";
                    connectionSpeedLabelUSB.Text = "";
                    TransferButton.Enabled = false;
                    ReadyToTransfer = false;
                }
            }
            catch (Exception xcp)
            {
                MessageBox.Show(xcp.Message, "Ya'...., something failed...");
            }
        }

        private void MyPort_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            try
            {
                if (InvokeRequired)
                {
                    this.Invoke(new MethodInvoker(delegate
                    {
                        if (OutputRichtext.Lines.Length > LOGMAX)
                        {
                            List<string> lines = OutputRichtext.Lines.ToList();
                            lines.RemoveRange(0, lines.Count - LOGMAX);
                            OutputRichtext.Lines = lines.ToArray();
                        }

                        string stmp = "";
                        stmp = myPort.ReadLine(); 

                        if (!gettingBIOS)
                        {
                            AddToRichTextBox(stmp);

                            if (stmp == "Get BIOS DateTime\r")
                            {
                                System.Threading.Thread.Sleep(1000);
                                SendROMDateTime();
                            }
                            else if (stmp == "Get BIOS\r")
                            {
                                System.Threading.Thread.Sleep(1000);
                                fs = new FileStream(ROMimageLocationLabel.Text + "\\" + ROMImageFileNameLabel.Text, FileMode.Open);
                                ROMTransferStatusProgressBar.Visible = true;
                                startTime = DateTime.Now;
                                ROMTransferStatusProgressBar.Value = 0;
                                //SendROMImage();
                                gettingBIOS = true;
                                ROMTransferStatusProgressBar.Value = 0;
                            }
                        }
                        else
                        {
                            if (stmp == "Get BIOS Complete\r")
                            {
                                AddToRichTextBox(stmp);

                                ROMTransferStatusProgressBar.Value = ROMTransferStatusProgressBar.Maximum;
                                endTime = DateTime.Now;
                                fs.Close();
                                ROMTransferStatusProgressBar.Value = ROMTransferStatusProgressBar.Maximum;
                                ROMTransferStatusLabel.Text = "Transfer of ROM image to Nano complete, taking " + endTime.Subtract(startTime).TotalSeconds.ToString("F2") + " seconds.";
                                gettingBIOS = false;
                            }
                            else
                            {
                                //already getting -- expecting a number for position
                                AddToRichTextBox("#" + stmp.Replace("\r",""));
                                uint newPos = uint.Parse(stmp);
                                fs.Seek(newPos, SeekOrigin.Begin);
                                serialBuffer[0] = (byte)fs.ReadByte();
                                AddToRichTextBox("&" + serialBuffer[0].ToString());
                                myPort.Write(serialBuffer, 0, 1);
                                ROMTransferStatusProgressBar.Value++;
                            }
                            this.Invalidate();
                        }

                    }));
                }
                else
                {
                    //OutputRichtext.Text = myPort.ReadLine();
                }
            }
            catch (Exception xcp)
            {
                MessageBox.Show(xcp.Message, "Ya'...., something failed...");
            }
        }

        private void MyPortUSB_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            //not planning on receiving data, but leaving this in case of future need
            try
            {
                if (InvokeRequired)
                {
                    this.Invoke(new MethodInvoker(delegate
                    {
                        if (OutputRichtext.Lines.Length > LOGMAX)
                        {
                            List<string> lines = OutputRichtext.Lines.ToList();
                            lines.RemoveRange(0, lines.Count - LOGMAX);
                            OutputRichtext.Lines = lines.ToArray();
                        }

                        string stmp = "";
                        stmp = myPortUSB.ReadLine();

                            AddToRichTextBox(stmp);
                    }));
                }
                else
                {
                    //OutputRichtext.Text = myPortUSB.ReadLine();
                }
            }
            catch (Exception xcp)
            {
                MessageBox.Show(xcp.Message, "Ya'...., something failed...");
            }
        }

        void AddToRichTextBox(string stmp)
        {
            OutputRichtext.Text += stmp;
            OutputRichtext.SelectionStart = OutputRichtext.Text.Length;
            OutputRichtext.ScrollToCaret();
            OutputRichtext.Invalidate();
        }

        void SendROMDateTime()
        {
            UpdateROMData();
            myPort.WriteLine(ROMImageLastModified.Text);
        }
        
        public void SendROMImage()
        {
            FileStream fs = new FileStream(ROMimageLocationLabel.Text + "\\" + ROMImageFileNameLabel.Text, FileMode.Open);
            
            ROMTransferStatusProgressBar.Visible = true;
            DateTime startTime = DateTime.Now;
            ROMTransferStatusProgressBar.Value = 0;
            for(int i=0;i<(256 * 1024);i++)           // loop 256K times, since processing one byte per loop
            {
                serialBuffer[0] = (byte)fs.ReadByte();
                myPortUSB.Write(serialBuffer, 0, 1);
                ROMTransferStatusProgressBar.Value++;
                //ROMTransferStatusLabel.Text = i.ToString("X5") + ": " + serialBuffer[0].ToString("X2");
                Application.DoEvents();
            }
            DateTime endTime = DateTime.Now;
            fs.Close();
            ROMTransferStatusProgressBar.Value = ROMTransferStatusProgressBar.Maximum;
            ROMTransferStatusLabel.Text = "Transfer of ROM image to Due complete, taking " + endTime.Subtract(startTime).TotalSeconds.ToString("F2") + " seconds.";
        }
        
        private void RuntimeUI_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                if (myPort != null && myPort.IsOpen)
                {
                    myPort.Close();
                }
                if (myPortUSB != null && myPortUSB.IsOpen)
                {
                    myPortUSB.Close();
                }
                if (fs != null)
                {
                    fs.Dispose();
                }
                mainForm.Visible = true;
            }
            catch (Exception xcp)
            {
                MessageBox.Show(xcp.Message, "Ya'...., something failed...");
            }
        }

        private void PortsCombo_SelectedIndexChanged(object sender, EventArgs e)
        {
            ConnectButton.Enabled = true;
        }
        private void PortsComboUSB_SelectedIndexChanged(object sender, EventArgs e)
        {
            ConnectButtonUSB.Enabled = true;
        }

        private void ChangeROMButton_Click(object sender, EventArgs e)
        {
            if(openFileDialog1.ShowDialog()==DialogResult.OK)
            {
                ROMimageLocationLabel.Text = Path.GetDirectoryName(openFileDialog1.FileName);
                ROMImageFileNameLabel.Text= Path.GetFileName(openFileDialog1.FileName);
                Settings.Default.ROMImage = openFileDialog1.FileName;
                Settings.Default.Save();
                UpdateROMData();
            }
        }

        private void TestTransferButton_Click(object sender, EventArgs e)
        {
            SendROMImage();
        }

        private void SendButton_Click(object sender, EventArgs e)
        {
            myPort.Write(SendTextTextBox.Text);
        }

        private void RefreshButton_Click(object sender, EventArgs e)
        {
            UpdateROMData();
        }




        private void PortsComboUSB_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            ConnectButtonUSB.Enabled = true;
        }
    }

}
