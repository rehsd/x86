﻿namespace Monitor_286_Win
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.DebuggerButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.RuntimeUIButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // DebuggerButton
            // 
            this.DebuggerButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DebuggerButton.Location = new System.Drawing.Point(12, 12);
            this.DebuggerButton.Name = "DebuggerButton";
            this.DebuggerButton.Size = new System.Drawing.Size(201, 37);
            this.DebuggerButton.TabIndex = 0;
            this.DebuggerButton.Text = "&Debugger";
            this.DebuggerButton.UseVisualStyleBackColor = true;
            this.DebuggerButton.Click += new System.EventHandler(this.DebuggerButton_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 56);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(231, 90);
            this.label1.TabIndex = 1;
            this.label1.Text = resources.GetString("label1.Text");
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(231, 56);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(224, 75);
            this.label2.TabIndex = 3;
            this.label2.Text = "Leverages Arduino Nano on 286 system\r\nfor two-way serial communications.\r\nSupport" +
    "s onboard BIOS update\r\nfunctionality. Intended for high-speed\r\noperation.";
            // 
            // RuntimeUIButton
            // 
            this.RuntimeUIButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RuntimeUIButton.Location = new System.Drawing.Point(230, 12);
            this.RuntimeUIButton.Name = "RuntimeUIButton";
            this.RuntimeUIButton.Size = new System.Drawing.Size(201, 37);
            this.RuntimeUIButton.TabIndex = 2;
            this.RuntimeUIButton.Text = "&Runtime UI";
            this.RuntimeUIButton.UseVisualStyleBackColor = true;
            this.RuntimeUIButton.Click += new System.EventHandler(this.RuntimeUIButton_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(454, 161);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.RuntimeUIButton);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.DebuggerButton);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "MainForm";
            this.Text = "286 Debugger / Monitor   v0.01";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button DebuggerButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button RuntimeUIButton;
    }
}