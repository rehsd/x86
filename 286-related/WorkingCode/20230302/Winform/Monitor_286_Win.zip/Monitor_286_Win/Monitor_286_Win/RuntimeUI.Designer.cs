﻿
namespace Monitor_286_Win
{
    partial class RuntimeUI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RuntimeUI));
            this.connectionSpeedLabel = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.connectionStatusPictureBox = new System.Windows.Forms.PictureBox();
            this.PortsCombo = new System.Windows.Forms.ComboBox();
            this.ConnectButton = new System.Windows.Forms.Button();
            this.OutputRichtext = new System.Windows.Forms.RichTextBox();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.label1 = new System.Windows.Forms.Label();
            this.ROMimageLocationLabel = new System.Windows.Forms.Label();
            this.ROMImageFileNameLabel = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.ChangeROMButton = new System.Windows.Forms.Button();
            this.ROMImageSizeLabel = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.ROMImageLastModified = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.SendTextTextBox = new System.Windows.Forms.TextBox();
            this.SendButton = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.ROMTransferStatusProgressBar = new System.Windows.Forms.ProgressBar();
            this.label7 = new System.Windows.Forms.Label();
            this.TransferButton = new System.Windows.Forms.Button();
            this.ROMTransferStatusLabel = new System.Windows.Forms.Label();
            this.RefreshButton = new System.Windows.Forms.Button();
            this.connectionSpeedLabelUSB = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.connectionStatusPictureBoxUSB = new System.Windows.Forms.PictureBox();
            this.PortsComboUSB = new System.Windows.Forms.ComboBox();
            this.ConnectButtonUSB = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.connectionStatusPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.connectionStatusPictureBoxUSB)).BeginInit();
            this.SuspendLayout();
            // 
            // connectionSpeedLabel
            // 
            this.connectionSpeedLabel.Font = new System.Drawing.Font("Segoe UI", 7F);
            this.connectionSpeedLabel.Location = new System.Drawing.Point(392, 12);
            this.connectionSpeedLabel.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.connectionSpeedLabel.Name = "connectionSpeedLabel";
            this.connectionSpeedLabel.Size = new System.Drawing.Size(118, 16);
            this.connectionSpeedLabel.TabIndex = 37;
            this.connectionSpeedLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(9, 13);
            this.label39.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(64, 15);
            this.label39.TabIndex = 36;
            this.label39.Text = "Serial Port";
            // 
            // connectionStatusPictureBox
            // 
            this.connectionStatusPictureBox.BackColor = System.Drawing.Color.Red;
            this.connectionStatusPictureBox.Location = new System.Drawing.Point(372, 14);
            this.connectionStatusPictureBox.Margin = new System.Windows.Forms.Padding(1);
            this.connectionStatusPictureBox.Name = "connectionStatusPictureBox";
            this.connectionStatusPictureBox.Size = new System.Drawing.Size(18, 15);
            this.connectionStatusPictureBox.TabIndex = 35;
            this.connectionStatusPictureBox.TabStop = false;
            // 
            // PortsCombo
            // 
            this.PortsCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.PortsCombo.FormattingEnabled = true;
            this.PortsCombo.Location = new System.Drawing.Point(76, 11);
            this.PortsCombo.Margin = new System.Windows.Forms.Padding(2);
            this.PortsCombo.Name = "PortsCombo";
            this.PortsCombo.Size = new System.Drawing.Size(216, 21);
            this.PortsCombo.TabIndex = 33;
            this.PortsCombo.SelectedIndexChanged += new System.EventHandler(this.PortsCombo_SelectedIndexChanged);
            // 
            // ConnectButton
            // 
            this.ConnectButton.Enabled = false;
            this.ConnectButton.Location = new System.Drawing.Point(299, 11);
            this.ConnectButton.Margin = new System.Windows.Forms.Padding(1);
            this.ConnectButton.Name = "ConnectButton";
            this.ConnectButton.Size = new System.Drawing.Size(72, 21);
            this.ConnectButton.TabIndex = 34;
            this.ConnectButton.Text = "&Connect";
            this.ConnectButton.UseVisualStyleBackColor = true;
            this.ConnectButton.Click += new System.EventHandler(this.ConnectButton_Click);
            // 
            // OutputRichtext
            // 
            this.OutputRichtext.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.OutputRichtext.BackColor = System.Drawing.Color.Black;
            this.OutputRichtext.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OutputRichtext.ForeColor = System.Drawing.Color.White;
            this.OutputRichtext.Location = new System.Drawing.Point(11, 86);
            this.OutputRichtext.Margin = new System.Windows.Forms.Padding(2);
            this.OutputRichtext.Name = "OutputRichtext";
            this.OutputRichtext.Size = new System.Drawing.Size(452, 357);
            this.OutputRichtext.TabIndex = 38;
            this.OutputRichtext.Text = "";
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.Filter = "ROM Images|*.bin|All files|*.*";
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 5.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(486, 65);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(205, 24);
            this.label1.TabIndex = 39;
            this.label1.Text = "ROM Image Location";
            // 
            // ROMimageLocationLabel
            // 
            this.ROMimageLocationLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.ROMimageLocationLabel.AutoSize = true;
            this.ROMimageLocationLabel.Location = new System.Drawing.Point(486, 82);
            this.ROMimageLocationLabel.Name = "ROMimageLocationLabel";
            this.ROMimageLocationLabel.Size = new System.Drawing.Size(16, 15);
            this.ROMimageLocationLabel.TabIndex = 40;
            this.ROMimageLocationLabel.Text = "...";
            // 
            // ROMImageFileNameLabel
            // 
            this.ROMImageFileNameLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.ROMImageFileNameLabel.AutoSize = true;
            this.ROMImageFileNameLabel.Location = new System.Drawing.Point(486, 142);
            this.ROMImageFileNameLabel.Name = "ROMImageFileNameLabel";
            this.ROMImageFileNameLabel.Size = new System.Drawing.Size(16, 15);
            this.ROMImageFileNameLabel.TabIndex = 42;
            this.ROMImageFileNameLabel.Text = "...";
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 5.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(486, 125);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(222, 24);
            this.label3.TabIndex = 41;
            this.label3.Text = "ROM Image File Name";
            // 
            // ChangeROMButton
            // 
            this.ChangeROMButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.ChangeROMButton.Location = new System.Drawing.Point(890, 51);
            this.ChangeROMButton.Margin = new System.Windows.Forms.Padding(1);
            this.ChangeROMButton.Name = "ChangeROMButton";
            this.ChangeROMButton.Size = new System.Drawing.Size(113, 30);
            this.ChangeROMButton.TabIndex = 43;
            this.ChangeROMButton.Text = "Change &ROM";
            this.ChangeROMButton.UseVisualStyleBackColor = true;
            this.ChangeROMButton.Click += new System.EventHandler(this.ChangeROMButton_Click);
            // 
            // ROMImageSizeLabel
            // 
            this.ROMImageSizeLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.ROMImageSizeLabel.AutoSize = true;
            this.ROMImageSizeLabel.Location = new System.Drawing.Point(486, 204);
            this.ROMImageSizeLabel.Name = "ROMImageSizeLabel";
            this.ROMImageSizeLabel.Size = new System.Drawing.Size(16, 15);
            this.ROMImageSizeLabel.TabIndex = 45;
            this.ROMImageSizeLabel.Text = "...";
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 5.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(486, 188);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(166, 24);
            this.label4.TabIndex = 44;
            this.label4.Text = "ROM Image Size";
            // 
            // ROMImageLastModified
            // 
            this.ROMImageLastModified.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.ROMImageLastModified.AutoSize = true;
            this.ROMImageLastModified.Location = new System.Drawing.Point(742, 204);
            this.ROMImageLastModified.Name = "ROMImageLastModified";
            this.ROMImageLastModified.Size = new System.Drawing.Size(16, 15);
            this.ROMImageLastModified.TabIndex = 47;
            this.ROMImageLastModified.Text = "...";
            // 
            // label6
            // 
            this.label6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 5.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(742, 188);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(249, 24);
            this.label6.TabIndex = 46;
            this.label6.Text = "ROM Image Last Modified";
            // 
            // SendTextTextBox
            // 
            this.SendTextTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.SendTextTextBox.Enabled = false;
            this.SendTextTextBox.Location = new System.Drawing.Point(75, 61);
            this.SendTextTextBox.Name = "SendTextTextBox";
            this.SendTextTextBox.Size = new System.Drawing.Size(333, 20);
            this.SendTextTextBox.TabIndex = 48;
            // 
            // SendButton
            // 
            this.SendButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.SendButton.Enabled = false;
            this.SendButton.Location = new System.Drawing.Point(412, 63);
            this.SendButton.Margin = new System.Windows.Forms.Padding(1);
            this.SendButton.Name = "SendButton";
            this.SendButton.Size = new System.Drawing.Size(51, 20);
            this.SendButton.TabIndex = 49;
            this.SendButton.Text = "&Send";
            this.SendButton.UseVisualStyleBackColor = true;
            this.SendButton.Click += new System.EventHandler(this.SendButton_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 61);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(62, 15);
            this.label2.TabIndex = 50;
            this.label2.Text = "Send Text";
            // 
            // ROMTransferStatusProgressBar
            // 
            this.ROMTransferStatusProgressBar.Location = new System.Drawing.Point(623, 254);
            this.ROMTransferStatusProgressBar.Maximum = 262144;
            this.ROMTransferStatusProgressBar.Name = "ROMTransferStatusProgressBar";
            this.ROMTransferStatusProgressBar.Size = new System.Drawing.Size(331, 23);
            this.ROMTransferStatusProgressBar.Step = 1;
            this.ROMTransferStatusProgressBar.Style = System.Windows.Forms.ProgressBarStyle.Continuous;
            this.ROMTransferStatusProgressBar.TabIndex = 51;
            this.ROMTransferStatusProgressBar.Visible = false;
            // 
            // label7
            // 
            this.label7.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 5.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(485, 261);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(202, 24);
            this.label7.TabIndex = 52;
            this.label7.Text = "ROM Transfer Status";
            this.label7.Visible = false;
            // 
            // TransferButton
            // 
            this.TransferButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.TransferButton.Enabled = false;
            this.TransferButton.Location = new System.Drawing.Point(840, 403);
            this.TransferButton.Margin = new System.Windows.Forms.Padding(1);
            this.TransferButton.Name = "TransferButton";
            this.TransferButton.Size = new System.Drawing.Size(151, 30);
            this.TransferButton.TabIndex = 53;
            this.TransferButton.Text = "Transfer BIOS to DUE";
            this.TransferButton.UseVisualStyleBackColor = true;
            this.TransferButton.Click += new System.EventHandler(this.TestTransferButton_Click);
            // 
            // ROMTransferStatusLabel
            // 
            this.ROMTransferStatusLabel.Location = new System.Drawing.Point(620, 288);
            this.ROMTransferStatusLabel.Name = "ROMTransferStatusLabel";
            this.ROMTransferStatusLabel.Size = new System.Drawing.Size(332, 18);
            this.ROMTransferStatusLabel.TabIndex = 54;
            // 
            // RefreshButton
            // 
            this.RefreshButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.RefreshButton.Location = new System.Drawing.Point(1173, 179);
            this.RefreshButton.Margin = new System.Windows.Forms.Padding(1);
            this.RefreshButton.Name = "RefreshButton";
            this.RefreshButton.Size = new System.Drawing.Size(53, 30);
            this.RefreshButton.TabIndex = 55;
            this.RefreshButton.Text = "Refresh";
            this.RefreshButton.UseVisualStyleBackColor = true;
            this.RefreshButton.Click += new System.EventHandler(this.RefreshButton_Click);
            // 
            // connectionSpeedLabelUSB
            // 
            this.connectionSpeedLabelUSB.Font = new System.Drawing.Font("Segoe UI", 7F);
            this.connectionSpeedLabelUSB.Location = new System.Drawing.Point(873, 9);
            this.connectionSpeedLabelUSB.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.connectionSpeedLabelUSB.Name = "connectionSpeedLabelUSB";
            this.connectionSpeedLabelUSB.Size = new System.Drawing.Size(118, 16);
            this.connectionSpeedLabelUSB.TabIndex = 60;
            this.connectionSpeedLabelUSB.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(525, 12);
            this.label8.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(32, 15);
            this.label8.TabIndex = 59;
            this.label8.Text = "USB";
            // 
            // connectionStatusPictureBoxUSB
            // 
            this.connectionStatusPictureBoxUSB.BackColor = System.Drawing.Color.Red;
            this.connectionStatusPictureBoxUSB.Location = new System.Drawing.Point(853, 11);
            this.connectionStatusPictureBoxUSB.Margin = new System.Windows.Forms.Padding(1);
            this.connectionStatusPictureBoxUSB.Name = "connectionStatusPictureBoxUSB";
            this.connectionStatusPictureBoxUSB.Size = new System.Drawing.Size(18, 15);
            this.connectionStatusPictureBoxUSB.TabIndex = 58;
            this.connectionStatusPictureBoxUSB.TabStop = false;
            // 
            // PortsComboUSB
            // 
            this.PortsComboUSB.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.PortsComboUSB.FormattingEnabled = true;
            this.PortsComboUSB.Location = new System.Drawing.Point(557, 8);
            this.PortsComboUSB.Margin = new System.Windows.Forms.Padding(2);
            this.PortsComboUSB.Name = "PortsComboUSB";
            this.PortsComboUSB.Size = new System.Drawing.Size(216, 21);
            this.PortsComboUSB.TabIndex = 56;
            this.PortsComboUSB.SelectedIndexChanged += new System.EventHandler(this.PortsComboUSB_SelectedIndexChanged_1);
            // 
            // ConnectButtonUSB
            // 
            this.ConnectButtonUSB.Enabled = false;
            this.ConnectButtonUSB.Location = new System.Drawing.Point(780, 8);
            this.ConnectButtonUSB.Margin = new System.Windows.Forms.Padding(1);
            this.ConnectButtonUSB.Name = "ConnectButtonUSB";
            this.ConnectButtonUSB.Size = new System.Drawing.Size(72, 21);
            this.ConnectButtonUSB.TabIndex = 57;
            this.ConnectButtonUSB.Text = "&Connect";
            this.ConnectButtonUSB.UseVisualStyleBackColor = true;
            this.ConnectButtonUSB.Click += new System.EventHandler(this.ConnectButtonUSB_Click);
            // 
            // RuntimeUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1023, 454);
            this.Controls.Add(this.connectionSpeedLabelUSB);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.connectionStatusPictureBoxUSB);
            this.Controls.Add(this.PortsComboUSB);
            this.Controls.Add(this.ConnectButtonUSB);
            this.Controls.Add(this.RefreshButton);
            this.Controls.Add(this.ROMTransferStatusLabel);
            this.Controls.Add(this.TransferButton);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.ROMTransferStatusProgressBar);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.SendButton);
            this.Controls.Add(this.SendTextTextBox);
            this.Controls.Add(this.ROMImageLastModified);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.ROMImageSizeLabel);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.ChangeROMButton);
            this.Controls.Add(this.ROMImageFileNameLabel);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.ROMimageLocationLabel);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.OutputRichtext);
            this.Controls.Add(this.connectionSpeedLabel);
            this.Controls.Add(this.label39);
            this.Controls.Add(this.connectionStatusPictureBox);
            this.Controls.Add(this.PortsCombo);
            this.Controls.Add(this.ConnectButton);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "RuntimeUI";
            this.Text = "80286 Runtime UI       v0.01";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.RuntimeUI_FormClosing);
            this.Load += new System.EventHandler(this.RuntimeUI_Load);
            ((System.ComponentModel.ISupportInitialize)(this.connectionStatusPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.connectionStatusPictureBoxUSB)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label connectionSpeedLabel;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.PictureBox connectionStatusPictureBox;
        private System.Windows.Forms.ComboBox PortsCombo;
        private System.Windows.Forms.Button ConnectButton;
        private System.Windows.Forms.RichTextBox OutputRichtext;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label ROMimageLocationLabel;
        private System.Windows.Forms.Label ROMImageFileNameLabel;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button ChangeROMButton;
        private System.Windows.Forms.Label ROMImageSizeLabel;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label ROMImageLastModified;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox SendTextTextBox;
        private System.Windows.Forms.Button SendButton;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ProgressBar ROMTransferStatusProgressBar;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button TransferButton;
        private System.Windows.Forms.Label ROMTransferStatusLabel;
        private System.Windows.Forms.Button RefreshButton;
        private System.Windows.Forms.Label connectionSpeedLabelUSB;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.PictureBox connectionStatusPictureBoxUSB;
        private System.Windows.Forms.ComboBox PortsComboUSB;
        private System.Windows.Forms.Button ConnectButtonUSB;
    }
}

