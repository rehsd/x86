﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Monitor_286_Win
{
    public partial class MainForm : Form
    {
        RuntimeUI r;
        public MainForm()
        {
            InitializeComponent();
        }


        private void DebuggerButton_Click(object sender, EventArgs e)
        {
            Debugger d = new Debugger();
            d.Show(this);
            //this.WindowState = FormWindowState.Minimized;
        }

        private void RuntimeUIButton_Click(object sender, EventArgs e)
        {
            r = new RuntimeUI(this);
            r.Show();
            this.Visible = false;
        }
    }
}
